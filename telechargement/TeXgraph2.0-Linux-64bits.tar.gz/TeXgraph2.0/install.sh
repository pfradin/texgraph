#!/bin/sh
version=2.0
nbparam=$#
bureau="$HOME/Bureau"
test ! -d "$HOME/Bureau" && bureau="$HOME/Desktop"

if [ $nbparam = 0 ] 
then #pas de parametres -> mode install
 if  test -w "/usr/local" #root?
 then 
  echo -n "You are connected as root, 
 TeXgraph will be installed in /usr/local/share/TeXgraph.
 Are you ok (y/n)?:"
    read rep
    case $rep in
    [nN]*) exit 1;;
    esac
    prefix="/usr/local"
    texgraphpath="$prefix/share/TeXgraph"
    binpath="$prefix/bin"
    test -d "$prefix/share/texmf" || mkdir "$prefix/share/texmf"
    texmfpath="$prefix/share/texmf"
    desktoppath="/usr/share/applications"
    iconpath="/usr/share/icons"
 else #on n'est pas en root mais en local
  echo -n "You are not connected as root.
 TeXgraph will be installed in $HOME/<path>/TeXgraph.
 Enter the <path> (can be empty):"
  read rep
 if test -n "$rep" 
 then
     prefix="$HOME/$rep"
 else
    prefix="$HOME"
 fi
 if test ! -d "$prefix"
 then 
    echo "The folder "$prefix" is not valid!" 
    exit 0
 else
    echo -n "TeXgraph will be installed in $prefix/TeXgraph.
 Are you ok (y/n)?:"
    read rep
    case $rep in
    [nN]*) exit 1;;
    esac
        test ! -d "$HOME/bin" && mkdir "$HOME/bin"
    test ! -d "$HOME/texmf" && mkdir "$HOME/texmf"
    texgraphpath="$prefix/TeXgraph"
    binpath="$HOME/bin"
    texmfpath="$HOME/texmf"
    desktoppath="$bureau"
    if test ! -d "$HOME/.icons"
    then 
        mkdir ~/.icons
    fi
    iconpath="$HOME/.icons"
 fi
 fi
else #mode update il doit y avoir un argument
 prefix="$1"    #chemin d'accès au dossier TeXgraph ex: "/usr/local" ou "$HOME"
 if  [ "$prefix" = "/usr/local" ]
 then #on avait une install en root
    if test ! -w "/usr/local"
    then
        echo "You should be connected as root for this update!"
        exit 0
    fi
    texgraphpath="$prefix/share/TeXgraph"
    binpath="$prefix/bin"
    test -d "$prefix/share/texmf" || mkdir "$prefix/share/texmf"
    texmfpath="$prefix/share/texmf"
    desktoppath="/usr/share/applications"
    iconpath="/usr/share/icons"
 else #on avait une install en local
        test ! -d "$HOME/bin" && mkdir "$HOME/bin"
    test ! -d "$HOME/texmf" && mkdir "$HOME/texmf"
    texgraphpath="$prefix/TeXgraph"
    binpath="$HOME/bin"
    texmfpath="$HOME/texmf"
    desktoppath="$bureau"
    if test ! -d "$HOME/.icons"
    then 
        mkdir "$HOME/.icons"
    fi
    iconpath="$HOME/.icons"
 fi
fi
if test -d "$HOME/.TeXgraph"
then
    echo "The folder $Home/.TeXgraph may contain TeX files."
    echo -n "Do you want to keep them (y/n, no is advised)?:"
    read rep
    case $rep in
    [nN]*) rm -f $HOME/.TeXgraph/*.tex;;
    esac
fi
# copie du fichier texgraph.sty et TeXgraph.pdf
echo "installing the package in texgraph.sty in $texmfpath/tex/latex/TeXgraph..."
test -d "$texmfpath"/tex || mkdir "$texmfpath"/tex
test -d "$texmfpath"/tex/latex || mkdir "$texmfpath"/tex/latex
test -d "$texmfpath"/tex/latex/TeXgraph || mkdir "$texmfpath"/tex/latex/TeXgraph
cp -f TeXgraph/texgraph.sty "$texmfpath"/tex/latex/TeXgraph
test -d "$texmfpath"/doc || mkdir "$texmfpath"/doc
test -d "$texmfpath"/doc/TeXgraph || mkdir "$texmfpath"/doc/TeXgraph
cp -f TeXgraph/doc/TeXgraph.pdf "$texmfpath"/doc/TeXgraph
texhash
# copie de l'icone
cp -f TeXgraph/TeXgraphIco.png  "$iconpath"
# copie des exécutables et cie
echo "installing files in $texgraphpath..."
test -d "$texgraphpath" && rm -rf "$texgraphpath"
mkdir "$texgraphpath"
cp -r TeXgraph/* "$texgraphpath"
# génération des 3 scripts

#startTeXgraph
echo "Generating scripts in $binpath..."
echo "#!/bin/sh
export TeXgraphDir=\"$texgraphpath\"
export TeXgraphDocDir=\"$texgraphpath/doc\"
export PATH=\"$texgraphpath:\$PATH\"
\"\$TeXgraphDir\"/TeXgraph \"\$1\"" > $binpath/startTeXgraph
chmod 755 $binpath/startTeXgraph

#CmdTeXgraph
echo "#!/bin/sh
chemin=\"$texgraphpath\"

patienter() { # wait for disparition of TeXgraphServer.cmd file
    while test -f \"\$HOME/.TeXgraph/TeXgraphServer.cmd\"
    do
        sleep 0.1s
    done
}
test -d \"\$HOME/.TeXgraph\" || mkdir \"\$HOME/.TeXgraph\"
if [ \"\$1\" = \"server\" ]
then
case \$2 in
on)     # server on
    export TeXgraphDir=\"\$chemin\"
    export PATH=\"\$chemin:\$PATH\"
    rm -f \"\$HOME/.TeXgraph/TeXgraphServer.cmd\"
    if test ! -f \"\$HOME/.TeXgraph/TeXgraphServer.On\" #déjà lancé??
    then
        \"\$TeXgraphDir\"/TeXgraphCmd -s > \"\$HOME/.TeXgraph/TeXgraphServer.log\" & #server mode on
        while test ! -f \"\$HOME/.TeXgraph/TeXgraphServer.On\"
        do
            sleep 0.1s
        done
    fi;;

off)    # stop
    cat > \"\$HOME/.TeXgraph/TeXgraphServer.cmd\" <<EOF
end
EOF
    patienter;;
esac

else   # \$1 is different than server
    if test -f \"\$HOME/.TeXgraph/TeXgraphServer.On\"
    then # execute file in server mode
    cat > \"\$HOME/.TeXgraph/TeXgraphServer.cmd\" <<EOF
\$1
\$2
\$3
EOF
    patienter
    else # execute file in normal mode
        export TeXgraphDir=\"\$chemin\"
        export PATH=\"\$chemin:\$PATH\"
        \"\$TeXgraphDir\"/TeXgraphCmd \$1 \$2 \"\$3\" > \"\$3.log\"
    fi
fi" > $binpath/CmdTeXgraph

#echo "#!/bin/sh
#export TeXgraphDir=\"$texgraphpath\"
#export PATH=\"$texgraphpath:\$PATH\"
#\"\$TeXgraphDir\"/TeXgraphCmd \$1 \$2 \"\$3\" > \"\$3.log\"" >$binpath/CmdTeXgraph
chmod 755 $binpath/CmdTeXgraph

#uninstallTeXgraph
echo "#!/bin/sh
# destruction of texgraph.sty
echo \"destruction of texgraph.sty...\"
test -d \"$texmfpath/tex/latex/TeXgraph\" && rm -rf \"$texmfpath/tex/latex/TeXgraph\"
test -d \"$texmfpath/doc/TeXgraph\" && rm -rf \"$texmfpath/doc/TeXgraph\"
texhash
# destruction des executables et cie
echo \"destruction of files...\"
test -d \"$texgraphpath\" && rm -rf \"$texgraphpath\"
# destruction des 3 scripts
echo \"destruction of scripts startTeXgraph, CmdTeXgraph and uninstallTeXgraph...\"
rm -f \"$binpath\"/startTeXgraph
rm -f \"$binpath\"/CmdTeXgraph
rm -f \"$binpath\"/uninstallTeXgraph
rm -f \"$desktoppath\"/TeXgraph.desktop
rm -f \"$iconpath\"/TeXgraphIco.png
rm -f \"$bureau\"/TeXgraph.desktop
echo \"Done\"" >$binpath/uninstallTeXgraph
chmod 755 $binpath/uninstallTeXgraph

#pour le menu
echo "[Desktop Entry]
Encoding=UTF-8
Version=$version
Type=Application
Terminal=false
Name=TeXgraph $version
GenericName=TeXgraph $version
Comment=Mathematic drawing program for LaTeX
Exec=startTeXgraph
Icon=$iconpath/TeXgraphIco.png" > "$desktoppath"/TeXgraph.desktop
chmod 755 "$desktoppath"/TeXgraph.desktop
if test -w "/usr/local"
then
    ln -s "$desktoppath"/TeXgraph.desktop "$bureau"/TeXgraph.desktop
fi

echo "Done"
echo "Attention: never execute startTeXgraph as root!"
echo "Press any key ..."
read a
