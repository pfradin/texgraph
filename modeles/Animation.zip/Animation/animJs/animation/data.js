info = {
"titre" : "",
"nbMin" : 1,
"nbMax" : 1,
"delai" : 100,
"ext" : "svg" }
